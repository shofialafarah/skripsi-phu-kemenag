---
title: API
layout: layout.njk
slug: api
---

# API

The generated API documentation, from the inline comments in [api.js](https://github.com/mozilla/pdf.js/blob/master/src/display/api.js), is available below.

<iframe src="draft/index.html" title="PDF.js API documentation"></iframe>
