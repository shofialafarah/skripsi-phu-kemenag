function usedByUsed() {}
function used() {
  usedByUsed();
}
used();
