class A {
  static {
    foo();
  }
  static {
    var a = 0;
  }
}
